#include <gui/containers/TetrominoI.hpp>

TetrominoI::TetrominoI()
{

}

void TetrominoI::initialize()
{
    TetrominoIBase::initialize();
}
