#include <gui/containers/EnterName.hpp>

EnterName::EnterName()
{

}

void EnterName::initialize()
{
    EnterNameBase::initialize();
}
