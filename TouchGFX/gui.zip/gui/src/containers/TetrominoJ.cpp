#include <gui/containers/TetrominoJ.hpp>

TetrominoJ::TetrominoJ()
{

}

void TetrominoJ::initialize()
{
    TetrominoJBase::initialize();
}
