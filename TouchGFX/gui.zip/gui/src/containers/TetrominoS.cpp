#include <gui/containers/TetrominoS.hpp>

TetrominoS::TetrominoS()
{

}

void TetrominoS::initialize()
{
    TetrominoSBase::initialize();
}
