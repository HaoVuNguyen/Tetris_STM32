#include <gui/containers/TetrominoL.hpp>

TetrominoL::TetrominoL()
{

}

void TetrominoL::initialize()
{
    TetrominoLBase::initialize();
}
