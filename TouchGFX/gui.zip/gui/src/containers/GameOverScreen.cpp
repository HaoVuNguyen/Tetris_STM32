#include <gui/containers/GameOverScreen.hpp>

GameOverScreen::GameOverScreen()
{

}

void GameOverScreen::initialize()
{
    GameOverScreenBase::initialize();
}
