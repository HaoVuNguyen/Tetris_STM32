#include <gui/containers/TetrominoZ.hpp>

TetrominoZ::TetrominoZ()
{

}

void TetrominoZ::initialize()
{
    TetrominoZBase::initialize();
}
