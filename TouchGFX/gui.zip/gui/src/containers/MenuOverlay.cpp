#include <gui/containers/MenuOverlay.hpp>

MenuOverlay::MenuOverlay()
{

}

void MenuOverlay::initialize()
{
    MenuOverlayBase::initialize();
}
