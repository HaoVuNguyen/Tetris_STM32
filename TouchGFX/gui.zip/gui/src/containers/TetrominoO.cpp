#include <gui/containers/TetrominoO.hpp>

TetrominoO::TetrominoO()
{

}

void TetrominoO::initialize()
{
    TetrominoOBase::initialize();
}
