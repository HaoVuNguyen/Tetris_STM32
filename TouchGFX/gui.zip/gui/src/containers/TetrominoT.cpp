#include <gui/containers/TetrominoT.hpp>

TetrominoT::TetrominoT()
{

}

void TetrominoT::initialize()
{
    TetrominoTBase::initialize();
}
