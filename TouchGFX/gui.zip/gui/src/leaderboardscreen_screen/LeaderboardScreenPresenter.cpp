#include <gui/leaderboardscreen_screen/LeaderboardScreenView.hpp>
#include <gui/leaderboardscreen_screen/LeaderboardScreenPresenter.hpp>

LeaderboardScreenPresenter::LeaderboardScreenPresenter(LeaderboardScreenView& v)
    : view(v)
{

}

void LeaderboardScreenPresenter::activate()
{

}

void LeaderboardScreenPresenter::deactivate()
{

}
