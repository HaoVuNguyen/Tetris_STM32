#include <gui/leaderboardscreen_screen/LeaderboardScreenView.hpp>

LeaderboardScreenView::LeaderboardScreenView()
{

}

void LeaderboardScreenView::setupScreen()
{
    LeaderboardScreenViewBase::setupScreen();
}

void LeaderboardScreenView::tearDownScreen()
{
    LeaderboardScreenViewBase::tearDownScreen();
}
