#include <gui/howtoplayscreen_screen/HowToPlayScreenView.hpp>

HowToPlayScreenView::HowToPlayScreenView()
{

}

void HowToPlayScreenView::setupScreen()
{
    HowToPlayScreenViewBase::setupScreen();
}

void HowToPlayScreenView::tearDownScreen()
{
    HowToPlayScreenViewBase::tearDownScreen();
}
