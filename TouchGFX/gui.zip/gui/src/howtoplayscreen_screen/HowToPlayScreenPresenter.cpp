#include <gui/howtoplayscreen_screen/HowToPlayScreenView.hpp>
#include <gui/howtoplayscreen_screen/HowToPlayScreenPresenter.hpp>

HowToPlayScreenPresenter::HowToPlayScreenPresenter(HowToPlayScreenView& v)
    : view(v)
{

}

void HowToPlayScreenPresenter::activate()
{

}

void HowToPlayScreenPresenter::deactivate()
{

}
