#ifndef ENTERNAME_HPP
#define ENTERNAME_HPP

#include <gui_generated/containers/EnterNameBase.hpp>

class EnterName : public EnterNameBase
{
public:
    EnterName();
    virtual ~EnterName() {}

    virtual void initialize();
protected:
};

#endif // ENTERNAME_HPP
