#ifndef TETROMINOI_HPP
#define TETROMINOI_HPP

#include <gui_generated/containers/TetrominoIBase.hpp>

class TetrominoI : public TetrominoIBase
{
public:
    TetrominoI();
    virtual ~TetrominoI() {}

    virtual void initialize();
protected:
};

#endif // TETROMINOI_HPP
