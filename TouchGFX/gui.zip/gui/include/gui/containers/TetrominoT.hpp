#ifndef TETROMINOT_HPP
#define TETROMINOT_HPP

#include <gui_generated/containers/TetrominoTBase.hpp>

class TetrominoT : public TetrominoTBase
{
public:
    TetrominoT();
    virtual ~TetrominoT() {}

    virtual void initialize();
protected:
};

#endif // TETROMINOT_HPP
