#include <images/BitmapDatabase.hpp>
